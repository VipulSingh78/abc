"""Utility functions for image handling"""

import os
import tensorflow as tf

def save_uploaded_image(image_data, filename, upload_dir='upload'):
    """Save uploaded image to disk"""
    os.makedirs(upload_dir, exist_ok=True)
    save_path = os.path.join(upload_dir, filename)
    
    with open(save_path, 'wb') as f:
        f.write(image_data.getbuffer())
    
    return save_path

def preprocess_image(image_path):
    """Preprocess image for model prediction"""
    try:
        image = tf.keras.utils.load_img(image_path, target_size=(224, 224))
        image_array = tf.keras.utils.img_to_array(image)
        return tf.expand_dims(image_array, axis=0)
    except Exception as e:
        raise Exception(f"Image preprocessing failed: {e}")